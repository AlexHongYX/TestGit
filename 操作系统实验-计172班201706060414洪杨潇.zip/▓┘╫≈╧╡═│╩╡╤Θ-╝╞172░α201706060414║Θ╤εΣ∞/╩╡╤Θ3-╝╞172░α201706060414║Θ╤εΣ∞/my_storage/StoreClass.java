/**
 * Created by xiaoaxiao on 2019/12/30
 * Description:
 */
public class StoreClass {

    int id;
    int[] ye = new int[64];

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public int[] getYe() {
        return ye;
    }

    public void setYe(int[] ye) {
        this.ye = ye;
    }
}
